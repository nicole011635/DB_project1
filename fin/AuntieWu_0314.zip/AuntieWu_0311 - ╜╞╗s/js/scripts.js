function cartAlert()
{
	alert("您已成功加入購物車!");
}